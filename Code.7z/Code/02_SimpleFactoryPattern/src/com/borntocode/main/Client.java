package com.borntocode.main;

import com.borntocode.factory.PostFactory;
import com.borntocode.pojo.Post;

public class Client {
	public static void main(String[] args) {
		Post post = PostFactory.createPost("blog");
		System.out.println(post);
	}
}
