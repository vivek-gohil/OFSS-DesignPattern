package com.borntocode.main;

import com.borntocode.factory.ImageFactory;
import com.borntocode.pojo.Image;

import javafx.geometry.Point2D;

public class Client {
	public static void main(String[] args) {
		Image image = ImageFactory.getImage("myimage.bmp");

		image.setLocation(new Point2D(10, 10));
		System.out.println("Image location is " + image.getLocation());

		System.out.println("Rendering image now");
		image.render();

	}
}
