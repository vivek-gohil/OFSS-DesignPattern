package com.borntocode.factory;
//Factory to get image objects

import com.borntocode.pojo.Image;
import com.borntocode.proxy.ImageProxy;

public class ImageFactory {
	// we will provide proxy to caller inseted of real object
	public static Image getImage(String name) {
		return new ImageProxy(name);
	}
}
