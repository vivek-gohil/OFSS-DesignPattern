package com.borntocode.dto;

public interface UserDTO {

}
