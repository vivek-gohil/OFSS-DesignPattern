package com.borntocode.main;

import com.borntocode.creator.JSONMessageCreator;
import com.borntocode.creator.MessageCreator;
import com.borntocode.creator.TextMessageCreator;
import com.borntocode.pojo.Message;

public class Client {
	public static void main(String[] args) {
		printMessage(new JSONMessageCreator());

		printMessage(new TextMessageCreator());
	}

	public static void printMessage(MessageCreator creator) {
		Message message = creator.getMessage();
		System.out.println(message);
	}
}
