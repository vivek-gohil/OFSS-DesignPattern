package com.borntocode.pojo;

public class JSONMessage extends Message {
	@Override
	public String getContent() {
		return "{\"JSON\": [] }";
	}
}
