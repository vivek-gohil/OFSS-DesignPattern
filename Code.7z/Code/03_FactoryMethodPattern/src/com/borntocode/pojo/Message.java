package com.borntocode.pojo;

public abstract class Message {
	public abstract String getContent();

	public void addDefaultHeaders() {
		// add some default header
	}

	public void encrypt() {
		// add some code to encrypt the content
	}
}
