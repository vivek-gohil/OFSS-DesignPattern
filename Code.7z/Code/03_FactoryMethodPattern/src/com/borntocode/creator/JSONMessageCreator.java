package com.borntocode.creator;

import com.borntocode.pojo.JSONMessage;
import com.borntocode.pojo.Message;

public class JSONMessageCreator extends MessageCreator {
	@Override
	public Message createMessage() {
		return new JSONMessage();
	}
}
