package com.borntocode.creator;

import com.borntocode.pojo.Message;
import com.borntocode.pojo.TextMessage;

public class TextMessageCreator extends MessageCreator {
	@Override
	public Message createMessage() {
		return new TextMessage();
	}
}
