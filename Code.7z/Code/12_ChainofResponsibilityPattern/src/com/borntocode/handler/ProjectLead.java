package com.borntocode.handler;

import com.borntocode.request.LeaveApplication;

//A concrete handler
public class ProjectLead extends Employee {

	public ProjectLead(LeaveApprover successor) {
		super("Project Lead", successor);
	}

	@Override
	protected boolean processRequest(LeaveApplication leaveApplication) {
		// type of leave is sick leave and duration is less than or equals to 2 days
		if (leaveApplication.getType() == LeaveApplication.Type.Sick) {
			if (leaveApplication.getNoOfDays() <= 2) {
				leaveApplication.approve(getApproverRole());
				return true;
			}
		}
		return false;
	}

}
