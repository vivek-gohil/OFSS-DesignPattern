package com.borntocode.main;

import java.time.LocalDate;

import com.borntocode.handler.Director;
import com.borntocode.handler.LeaveApprover;
import com.borntocode.handler.Manager;
import com.borntocode.handler.ProjectLead;
import com.borntocode.request.LeaveApplication;
import com.borntocode.request.LeaveApplication.Type;

public class Client {
	public static void main(String[] args) {
		LeaveApplication application = LeaveApplication.getBuilder().withType(Type.LOP).from(LocalDate.now())
				.to(LocalDate.of(2022, 05, 10)).build();

		System.out.println(application);

		System.out.println("**************************************************");

		LeaveApprover approver = createChain();

		approver.processLeaveApplication(application);
		System.out.println(application);
	}

	private static LeaveApprover createChain() {
		Director director = new Director(null);
		Manager manager = new Manager(director);
		ProjectLead lead = new ProjectLead(manager);
		return lead;
	}
}
