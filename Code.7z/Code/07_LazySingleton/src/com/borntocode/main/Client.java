package com.borntocode.main;

import com.borntocode.pojo.LazyRegistryIODH;

public class Client {
	public static void main(String[] args) {
		LazyRegistryIODH singleton = LazyRegistryIODH.getInstance();
		LazyRegistryIODH singleton2 = LazyRegistryIODH.getInstance();

		System.out.println(singleton.hashCode());
		System.out.println(singleton2.hashCode());

	}
}
