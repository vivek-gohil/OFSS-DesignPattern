package com.borntocode.main;

import com.borntocode.pojo.BusinessCardDesigner;
import com.borntocode.pojo.Employee;
import com.borntocode.pojo.EmployeeObjectAdapter;

public class Main {
	public static void main(String[] args) {
		Employee employee = new Employee();
		populateEmployeeData(employee);
		EmployeeObjectAdapter employeeObjectAdapter = new EmployeeObjectAdapter(employee);
		BusinessCardDesigner businessCardDesigner = new BusinessCardDesigner();
		String card = businessCardDesigner.designCard(employeeObjectAdapter);
		System.out.println(card);

	}

	public static void populateEmployeeData(Employee employee) {
		employee.setFullName("Vivek Gohil");
		employee.setJobTitle("Security Engineer");
		employee.setOfficeLocation("B-211 , WeWork , AB Road , Worli , Mumbai");
	}
}
