package com.borntocode.pojo;

public interface Customer {
	String getName();

	String getDesignation();

	String getAddress();

}
