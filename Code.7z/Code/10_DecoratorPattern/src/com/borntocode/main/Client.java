package com.borntocode.main;

import com.borntocode.pojo.Base64EncodedMessage;
import com.borntocode.pojo.HTMLEncodedMessage;
import com.borntocode.pojo.Message;
import com.borntocode.pojo.TextMessage;

public class Client {
	public static void main(String[] args) {
		Message message = new TextMessage("The <force> is stron with this one");
		System.out.println(message.getContent());

		Message decorator = new HTMLEncodedMessage(message);
		System.out.println(decorator.getContent());

		decorator = new Base64EncodedMessage(decorator);
		System.out.println(decorator.getContent());
	}
}
