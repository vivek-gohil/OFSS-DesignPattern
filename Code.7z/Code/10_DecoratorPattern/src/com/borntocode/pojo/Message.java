package com.borntocode.pojo;

public interface Message {
	String getContent();
}
