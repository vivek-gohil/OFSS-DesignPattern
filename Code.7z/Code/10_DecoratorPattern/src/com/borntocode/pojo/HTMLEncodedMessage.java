package com.borntocode.pojo;

import org.apache.commons.text.StringEscapeUtils;

public class HTMLEncodedMessage implements Message {

	private Message message;

	public HTMLEncodedMessage(Message message) {
		this.message = message;
	}

	@Override
	public String getContent() {
		return StringEscapeUtils.escapeHtml4(message.getContent());
	}

}
